package com.example.myapplication.backend;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Wrapper {
    public int value;
    public Wrapper (int value){
        this.value = value;
    }
}
